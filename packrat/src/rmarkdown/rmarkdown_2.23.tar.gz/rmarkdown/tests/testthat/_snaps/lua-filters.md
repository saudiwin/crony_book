# latex-divs.lua works with LaTeX (PDF)

    \begin{custom} content  \end{custom}

---

    \begin{custom} content  \end{custom}

---

    \begin{custom} content  \end{custom}

