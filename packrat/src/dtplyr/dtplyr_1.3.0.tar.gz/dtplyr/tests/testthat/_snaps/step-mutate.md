# unnamed arguments matching column names are ignored

    Code
      mutate(dt, y)
    Condition
      Error:
      ! object 'y' not found

