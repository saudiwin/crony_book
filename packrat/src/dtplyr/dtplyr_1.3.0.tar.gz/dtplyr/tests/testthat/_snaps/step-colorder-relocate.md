# can only supply one of .before and .after

    Code
      relocate(dt, y, .before = x, .after = x)
    Condition
      Error in `relocate()`:
      ! Can't supply both `.before` and `.after`.

