// This file is required so that package installation uses a C++ linker.
// See https://cran.r-project.org/doc/manuals/r-release/R-exts.html#External-C_002b_002b-code for the rationale.
