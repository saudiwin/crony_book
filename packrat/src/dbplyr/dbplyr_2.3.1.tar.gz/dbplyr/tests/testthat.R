library(testthat)
library(dbplyr)

test_check("dbplyr")
