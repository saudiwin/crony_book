library(testthat)
library(WDI)

test_check("WDI")
