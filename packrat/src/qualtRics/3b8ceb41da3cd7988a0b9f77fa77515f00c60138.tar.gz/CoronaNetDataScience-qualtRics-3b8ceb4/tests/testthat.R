library(testthat)
library(qualtRics)

test_check("qualtRics")
