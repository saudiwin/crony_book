## Release summary

This is the 14th CRAN release of qualtRics (the 8th since it has returned to CRAN after being archived). This release makes a change necessary to work with the latest version of [vcr](https://cran.r-project.org/package=vcr) (for automated testing), as well as some bug fixes and refactoring code for checking arguments.

## R CMD check results

0 errors | 0 warnings | 0 note
