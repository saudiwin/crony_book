globalVariables(c(
  "meta_levels", "name", "name_in_survey", "qidnames", "question_name",
  "question_type", "selector_supp", "supported", "type_supp", "value",
  "metadata_type", "JSON", "description", "ImportId", "choiceId", "id"
))
