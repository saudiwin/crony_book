set.seed(1234)
ndraws_vec <- c(1, 5)
nobsv_vec <- c(1, 4)
ncat_vec <- c(2, 3)
