.onLoad <- function(libname, pkgname) {
  library.dynam(pkgname, pkgname, libname)
}
